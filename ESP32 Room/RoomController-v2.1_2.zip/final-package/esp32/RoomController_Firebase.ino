/*
 * ============================================================
 *  Room Controller — ESP32 + Firebase Realtime Database
 *  Board  : ESP32 Dev Module
 *  Libraries: WiFi, HTTPClient, WiFiClientSecure, ArduinoJson
 *
 *  Flicker fix:
 *  - Slot refresh does NOT call applyState during active slot
 *  - Slots parsed into temp buffer first, only copied if valid
 *  - Bad HTTP responses always skipped — state never changes
 *  - Schedule check compares seconds not just minutes
 * ============================================================
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <time.h>

// ── YOUR CREDENTIALS ─────────────────────────────────────────
// Add up to 5 WiFi networks — ESP32 tries each in order
// If one fails it automatically tries the next one
// Leave unused entries as empty strings ""
struct WiFiNetwork { const char* ssid; const char* password; };

const WiFiNetwork wifiNetworks[] = {
  { "YOUR_WIFI_NAME_1",  "YOUR_WIFI_PASSWORD_1" },  // ← primary
  { "YOUR_WIFI_NAME_2",  "YOUR_WIFI_PASSWORD_2" },  // ← fallback 1
  { "YOUR_WIFI_NAME_3",  "YOUR_WIFI_PASSWORD_3" },  // ← fallback 2
  { "",                  ""                     },  // unused
  { "",                  ""                     },  // unused
};
const int WIFI_NETWORK_COUNT = 5;
int currentWiFiIdx = 0;  // tracks which network is currently connected

#define FIREBASE_URL   "https://roomcontrol-1d14d-default-rtdb.asia-southeast1.firebasedatabase.app"

// Timezone: IST India = 19800 | GMT = 0 | EST = -18000
#define GMT_OFFSET_SEC  19800
#define DST_OFFSET_SEC  0
// ─────────────────────────────────────────────────────────────

// Relay GPIO pins Room 1 to 6
const int RELAY_PINS[6] = { 26, 27, 14, 12, 13, 15 };

// LED GPIO pins Room 1 to 6
const int LED_PINS[6]   = {  2,  4,  5, 18, 19, 21 };

// ACTIVE LOW = most relay modules (LOW = relay ON)
// If relay turns ON with HIGH swap these:
// ── NC WIRING (Normally Closed) ──────────────────────────────
// Light ON  = relay de-energised = NC contact closed = GPIO HIGH
// Light OFF = relay energised    = NC contact open   = GPIO LOW
// When ESP32 is OFF → relay de-energised → NC closed → lights ON (safe fallback)
#define RELAY_ON  HIGH   // de-energise coil → NC closed → light ON
#define RELAY_OFF LOW    // energise coil    → NC open   → light OFF
#define LED_ON    HIGH
#define LED_OFF   LOW

// ── Room state ────────────────────────────────────────────────
struct Slot { int sh, sm, eh, em; bool recurring; };

struct Room {
  bool lightOn   = false;
  int  ovr       = -1;   // -1=auto  0=force OFF  1=force ON
  Slot slots[10];
  int  slotCount = 0;
  char name[20];
};

Room rooms[6];

unsigned long lastPollTime      = 0;
unsigned long lastScheduleCheck = 0;
unsigned long lastSlotRefresh   = 0;
unsigned long lastStatusPush    = 0;
int           lastDate          = -1;  // tracks day-of-month for midnight detection

// Intervals
const unsigned long POLL_INTERVAL     = 3000;   // override poll every 3 sec
const unsigned long SCHEDULE_INTERVAL = 10000;  // schedule check every 10 sec
const unsigned long SLOT_REFRESH      = 60000;  // slot refresh every 60 sec
const unsigned long HEARTBEAT         = 300000; // heartbeat every 5 min

// ── Time helpers ──────────────────────────────────────────────
int nowH()    { struct tm t; getLocalTime(&t); return t.tm_hour; }
int nowMn()   { struct tm t; getLocalTime(&t); return t.tm_min;  }
int nowSec()  { struct tm t; getLocalTime(&t); return t.tm_sec;  }
int nowMins() { return nowH() * 60 + nowMn(); }

String getTime() {
  struct tm t; getLocalTime(&t);
  char buf[9]; snprintf(buf, 9, "%02d:%02d:%02d", t.tm_hour, t.tm_min, t.tm_sec);
  return String(buf);
}

bool parseTime(String s, int &h, int &m) {
  s.trim();
  int c = s.indexOf(':');
  if (c < 0) return false;
  h = s.substring(0, c).toInt();
  m = s.substring(c + 1).toInt();
  return (h >= 0 && h < 24 && m >= 0 && m < 60);
}

// ── Relay + LED — only fires GPIO if state truly changes ──────
void setRelay(int idx, bool on) {
  if (rooms[idx].lightOn == on) return; // no change — do nothing
  rooms[idx].lightOn = on;
  digitalWrite(RELAY_PINS[idx], on ? RELAY_ON : RELAY_OFF);
  digitalWrite(LED_PINS[idx],   on ? LED_ON   : LED_OFF);
  Serial.printf("[%s] Room %d → %s\n", getTime().c_str(), idx+1, on?"ON":"OFF");
}

// ── mergeSlots — merge overlapping/adjacent slots into clean ranges ──
// Example: [9-11, 10-12] → [9-12]  [9-10, 11-12] → [9-10, 11-12]
// Called after parsing so ESP32 always works with clean non-overlapping slots
void mergeSlots(int idx) {
  if (rooms[idx].slotCount < 2) return;

  // Sort slots by start time
  for (int i = 0; i < rooms[idx].slotCount - 1; i++) {
    for (int j = i + 1; j < rooms[idx].slotCount; j++) {
      int si = rooms[idx].slots[i].sh * 60 + rooms[idx].slots[i].sm;
      int sj = rooms[idx].slots[j].sh * 60 + rooms[idx].slots[j].sm;
      if (sj < si) {
        Slot tmp = rooms[idx].slots[i];
        rooms[idx].slots[i] = rooms[idx].slots[j];
        rooms[idx].slots[j] = tmp;
      }
    }
  }

  // Merge overlapping or adjacent slots
  Slot merged[10];
  int  mergedCount = 0;
  merged[0] = rooms[idx].slots[0];
  mergedCount = 1;

  for (int i = 1; i < rooms[idx].slotCount; i++) {
    Slot &last = merged[mergedCount - 1];
    int lastEnd   = last.eh * 60 + last.em;
    int currStart = rooms[idx].slots[i].sh * 60 + rooms[idx].slots[i].sm;
    int currEnd   = rooms[idx].slots[i].eh * 60 + rooms[idx].slots[i].em;

    if (currStart <= lastEnd) {
      // Overlapping or adjacent — extend the end if needed
      if (currEnd > lastEnd) {
        last.eh = rooms[idx].slots[i].eh;
        last.em = rooms[idx].slots[i].em;
        Serial.printf("  Room %d: merged overlapping slots → %02d:%02d-%02d:%02d\n",
          idx+1, last.sh, last.sm, last.eh, last.em);
      }
      // else: current slot is fully contained — skip it
    } else {
      // No overlap — add as new slot
      merged[mergedCount++] = rooms[idx].slots[i];
    }
  }

  // Copy merged back
  rooms[idx].slotCount = mergedCount;
  for (int i = 0; i < mergedCount; i++) rooms[idx].slots[i] = merged[i];
}

// ── isInSlot — true if current time falls in ANY slot ────────
// Works correctly even with overlapping slots after mergeSlots()
bool isInSlot(int idx) {
  int nm = nowMins();
  for (int i = 0; i < rooms[idx].slotCount; i++) {
    int s = rooms[idx].slots[i].sh * 60 + rooms[idx].slots[i].sm;
    int e = rooms[idx].slots[i].eh * 60 + rooms[idx].slots[i].em;
    if (nm >= s && nm < e) return true;
  }
  return false;
}

// ── applyState — uses override first, then schedule ──────────
void applyState(int idx) {
  if      (rooms[idx].ovr == 1)  setRelay(idx, true);
  else if (rooms[idx].ovr == 0)  setRelay(idx, false);
  else                           setRelay(idx, isInSlot(idx));
}

// ── WiFi multi-network connect ────────────────────────────────
// Tries each network in wifiNetworks[] in order
// Returns true if connected, false if all failed
bool connectWiFi() {
  for (int n = 0; n < WIFI_NETWORK_COUNT; n++) {
    // Skip empty entries
    if (strlen(wifiNetworks[n].ssid) == 0) continue;

    Serial.printf("Trying WiFi %d: %s\n", n + 1, wifiNetworks[n].ssid);
    WiFi.disconnect(true);
    delay(300);
    WiFi.begin(wifiNetworks[n].ssid, wifiNetworks[n].password);

    int tries = 0;
    while (WiFi.status() != WL_CONNECTED && tries++ < 20) {
      delay(500);
      Serial.print(".");
      // Blink LED for the current network index
      digitalWrite(LED_PINS[n % 6], tries % 2 == 0 ? LED_ON : LED_OFF);
    }
    // Restore LED_ON after blink — NC mode: light is ON during boot
    digitalWrite(LED_PINS[n % 6], LED_ON);

    if (WiFi.status() == WL_CONNECTED) {
      currentWiFiIdx = n;
      Serial.printf("\nConnected to: %s  IP: %s\n",
        wifiNetworks[n].ssid, WiFi.localIP().toString().c_str());
      return true;
    }
    Serial.printf("\nFailed: %s\n", wifiNetworks[n].ssid);
  }
  return false;  // all networks failed
}

// ── WiFi watchdog — tries all networks if current drops ───────
void wifiWatchdog() {
  if (WiFi.status() == WL_CONNECTED) return;

  Serial.println("WiFi lost — trying all networks");
  // Flash all LEDs to signal WiFi lost
  for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_ON);
  delay(300);
  for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_OFF);
  delay(200);
  for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_ON);
  delay(300);
  for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_OFF);

  if (connectWiFi()) {
    Serial.println("WiFi restored");
    // Restore LEDs to correct room states after reconnect
    for (int i = 0; i < 6; i++) {
      digitalWrite(LED_PINS[i], rooms[i].lightOn ? LED_ON : LED_OFF);
    }
  } else {
    Serial.println("All WiFi failed — rebooting in 10s");
    delay(10000);
    ESP.restart();
  }
}

// ── LED startup test — quick blink then settle to match relay state ──
// NC mode: lights ON during boot, so LEDs end ON after test
void ledStartupTest() {
  // Quick 3 blinks on all LEDs
  for (int b = 0; b < 3; b++) {
    for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_ON);
    delay(150);
    for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_OFF);
    delay(100);
  }
  // End with all LEDs ON — matches NC relay state (lights ON during boot)
  for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_ON);
}

void blinkLED(int idx, int times, int ms) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_PINS[idx], LED_ON);  delay(ms);
    digitalWrite(LED_PINS[idx], LED_OFF); delay(ms);
  }
}

// ── HTTP helpers — returns "error" on failure ─────────────────
String fbGet(String path) {
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.begin(client, FIREBASE_URL + path + ".json");
  http.setTimeout(5000);
  int code = http.GET();
  String result = "error";
  if (code == 200) {
    result = http.getString();
    result.trim();
  } else {
    Serial.printf("fbGet failed %s code=%d\n", path.c_str(), code);
  }
  http.end();
  return result;
}

bool fbPut(String path, String jsonValue) {
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.begin(client, FIREBASE_URL + path + ".json");
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(5000);
  int code = http.PUT(jsonValue);
  http.end();
  return (code == 200);
}

// ── Push status back to Firebase ─────────────────────────────
void pushStatus(int idx) {
  String base = "/rooms/room" + String(idx + 1);
  fbPut(base + "/lightOn",  rooms[idx].lightOn ? "true" : "false");
  fbPut(base + "/lastSeen", "\"" + getTime() + "\"");
}

void pushAllStatus() {
  for (int i = 0; i < 6; i++) { pushStatus(i); delay(150); }
}

// ── Parse slots — into TEMP buffer, only copy if fully valid ──
void parseSlots(int idx, String json) {
  if (json == "null" || json == "" || json == "error" || json.length() < 5) {
    Serial.printf("  Room %d: no slots in Firebase\n", idx+1);
    rooms[idx].slotCount = 0;
    return;
  }

  Slot tempSlots[10];
  int  tempCount = 0;
  int  pos = 0;

  while (pos < (int)json.length() && tempCount < 10) {
    int si = json.indexOf("\"s\":\"", pos);
    int ei = json.indexOf("\"e\":\"", pos);
    if (si < 0 || ei < 0) break;
    String startStr = json.substring(si + 5, si + 10);
    String endStr   = json.substring(ei + 5, ei + 10);
    int sh, sm, eh, em;
    if (parseTime(startStr, sh, sm) && parseTime(endStr, eh, em)) {
      // Check for recurring flag in this slot object
      // Slot object spans from previous { to next }
      int objStart = json.lastIndexOf('{', si);
      int objEnd   = json.indexOf('}', ei);
      bool isRecurring = false;
      if (objStart >= 0 && objEnd >= 0) {
        String slotObj = json.substring(objStart, objEnd);
        isRecurring = slotObj.indexOf("\"recurring\":true") >= 0;
      }
      tempSlots[tempCount++] = {sh, sm, eh, em, isRecurring};
    }
    pos = max(si, ei) + 10;
  }

  if (tempCount > 0 || json == "[]") {
    rooms[idx].slotCount = tempCount;
    for (int i = 0; i < tempCount; i++) rooms[idx].slots[i] = tempSlots[i];
    mergeSlots(idx);
    Serial.printf("  Room %d: %d slots after merge\n", idx+1, rooms[idx].slotCount);
    for (int i = 0; i < rooms[idx].slotCount; i++) {
      Serial.printf("    [%02d:%02d-%02d:%02d %s]\n",
        rooms[idx].slots[i].sh, rooms[idx].slots[i].sm,
        rooms[idx].slots[i].eh, rooms[idx].slots[i].em,
        rooms[idx].slots[i].recurring ? "recurring" : "one-time");
    }
  } else {
    Serial.printf("  Room %d: parse gave 0 — keeping existing %d slots\n",
      idx+1, rooms[idx].slotCount);
  }
}

// ── Read all rooms from Firebase on boot ─────────────────────
void readAllRooms() {
  Serial.println("Reading rooms from Firebase...");
  String json = fbGet("/rooms");
  if (json == "" || json == "null" || json == "error") {
    Serial.println("  Error — keeping current state");
    return;
  }

  for (int i = 0; i < 6; i++) {
    String key = "\"room" + String(i + 1) + "\":{";
    int start = json.indexOf(key);
    if (start < 0) continue;
    String roomJson = json.substring(start);

    // ── Override — strict parsing, never reset on bad value ──
    int ovIdx = roomJson.indexOf("\"override\":");
    if (ovIdx >= 0) {
      String ovVal = roomJson.substring(ovIdx + 11, ovIdx + 16);
      ovVal.trim();
      if      (ovVal.startsWith("true"))  rooms[i].ovr = 1;
      else if (ovVal.startsWith("false")) rooms[i].ovr = 0;
      else if (ovVal.startsWith("null") || ovVal.startsWith("-1"))
                                          rooms[i].ovr = -1;
      // else: unknown/malformed — KEEP existing ovr, do not reset
      else Serial.printf("  Room %d: unknown override val '%s' — keeping ovr=%d\n",
        i+1, ovVal.c_str(), rooms[i].ovr);
    }
    // If override field missing entirely — keep existing ovr too
    // (do NOT reset to -1 just because field is absent)

    // Name
    int nameIdx = roomJson.indexOf("\"name\":\"");
    if (nameIdx >= 0) {
      int ns = nameIdx + 8;
      int ne = roomJson.indexOf("\"", ns);
      strncpy(rooms[i].name, roomJson.substring(ns, ne).c_str(), 20);
    }

    // Slots
    int slotIdx = roomJson.indexOf("\"slots\":[");
    if (slotIdx >= 0) {
      int as = slotIdx + 8;
      int ae = roomJson.indexOf("]", as) + 1;
      parseSlots(i, roomJson.substring(as, ae));
    } else {
      rooms[i].slotCount = 0;
    }

    applyState(i);
    Serial.printf("  Room %d (%s): ovr=%d slots=%d light=%s\n",
      i+1, rooms[i].name, rooms[i].ovr,
      rooms[i].slotCount, rooms[i].lightOn ? "ON" : "OFF");
  }
}

// ── Refresh slots only — does NOT touch relay state ──────────
// KEY FIX: separate from applyState so slot update never causes flicker
void refreshSlotsOnly() {
  Serial.println("Refreshing slots...");
  for (int i = 0; i < 6; i++) {
    String slotJson = fbGet("/rooms/room" + String(i+1) + "/slots");
    if (slotJson != "error") {
      int prevCount = rooms[i].slotCount;
      parseSlots(i, slotJson);
      // Only re-apply state if slot count actually changed
      if (rooms[i].slotCount != prevCount) {
        Serial.printf("  Room %d slots changed %d→%d — re-applying state\n",
          i+1, prevCount, rooms[i].slotCount);
        applyState(i);
      }
    }
    delay(150);
  }
}

// ── Poll overrides every 3 seconds ───────────────────────────
void pollOverrides() {
  for (int i = 0; i < 6; i++) {
    String val = fbGet("/rooms/room" + String(i + 1) + "/override");

    // Skip bad reads — NEVER change state on error
    if (val == "error" || val == "") { delay(100); continue; }

    int newOvr;
    if      (val == "true"  || val == "1")  newOvr = 1;
    else if (val == "false" || val == "0")  newOvr = 0;
    else if (val == "null"  || val == "-1") newOvr = -1;
    else {
      // Unknown value — skip, never change active override
      Serial.printf("Room %d: unexpected val '%s' — skipped\n", i+1, val.c_str());
      delay(100); continue;
    }

    // Extra guard: if manual override is active and new value is auto (-1)
    // only accept if Firebase returned full "null" string — not a short bad read
    if (rooms[i].ovr != -1 && newOvr == -1 && val.length() < 4) {
      Serial.printf("Room %d: suspicious null — keeping manual ovr=%d\n",
        i+1, rooms[i].ovr);
      delay(100); continue;
    }

    if (newOvr != rooms[i].ovr) {
      Serial.printf("Room %d override: %d → %d\n", i+1, rooms[i].ovr, newOvr);
      rooms[i].ovr = newOvr;
      applyState(i);
      pushStatus(i);
    }
    delay(100);
  }
}

// ── Midnight rollover — runs once when date changes ───────────
// Rule:
//   Recurring slots → today only, stay forever, never in tomorrow
//   One-time today  → deleted at midnight
//   One-time tomorrow → moves to today, tomorrow cleared after
void midnightRollover() {
  Serial.println("=== Midnight rollover ===");

  for (int i = 0; i < 6; i++) {
    String base = "/rooms/room" + String(i + 1);

    // Read tomorrow's one-time slots from Firebase
    String tomorrowJson = fbGet(base + "/slotsT");

    // ── Build new TODAY ───────────────────────────────────────
    // Keep today's recurring slots + add tomorrow's one-time slots
    String newTodayJson = "[";
    bool first = true;

    // Always keep recurring slots (they live here forever)
    for (int j = 0; j < rooms[i].slotCount; j++) {
      if (!rooms[i].slots[j].recurring) continue;
      if (!first) newTodayJson += ",";
      char s[6], e[6];
      snprintf(s, 6, "%02d:%02d", rooms[i].slots[j].sh, rooms[i].slots[j].sm);
      snprintf(e, 6, "%02d:%02d", rooms[i].slots[j].eh, rooms[i].slots[j].em);
      newTodayJson += "{\"s\":\"" + String(s) + "\",\"e\":\"" + String(e) + "\",\"recurring\":true}";
      first = false;
    }

    // Move tomorrow's one-time slots into today
    // (skip any recurring ones — recurring should only be in today)
    if (tomorrowJson != "null" && tomorrowJson != "" &&
        tomorrowJson != "error" && tomorrowJson.length() > 2) {
      int pos = 0;
      while (pos < (int)tomorrowJson.length()) {
        int si = tomorrowJson.indexOf("\"s\":\"", pos);
        int ei = tomorrowJson.indexOf("\"e\":\"", pos);
        if (si < 0 || ei < 0) break;
        int objStart = tomorrowJson.lastIndexOf('{', si);
        int objEnd   = tomorrowJson.indexOf('}', ei);
        if (objStart >= 0 && objEnd >= 0) {
          String obj = tomorrowJson.substring(objStart, objEnd + 1);
          // Only move one-time slots (skip recurring)
          if (obj.indexOf("\"recurring\":true") < 0) {
            String startStr = tomorrowJson.substring(si + 5, si + 10);
            String endStr   = tomorrowJson.substring(ei + 5, ei + 10);
            if (!first) newTodayJson += ",";
            newTodayJson += "{\"s\":\"" + startStr + "\",\"e\":\"" + endStr + "\"}";
            first = false;
          }
        }
        pos = max(si, ei) + 10;
      }
    }
    newTodayJson += "]";

    // Tomorrow is always cleared — user adds fresh one-time slots as needed
    // Recurring slots are never placed in tomorrow
    fbPut(base + "/slots",  newTodayJson);
    fbPut(base + "/slotsT", "[]");

    Serial.printf("  Room %d rolled over — recurring kept, tomorrow cleared\n", i+1);
    delay(200);
  }

  readAllRooms();
  Serial.println("=== Rollover complete ===");
}

// ── Check if date changed — called every minute ───────────────
void checkMidnight() {
  struct tm t; getLocalTime(&t);
  int currentDate = t.tm_mday;
  if (lastDate == -1) {
    lastDate = currentDate;  // first run — just record date
    return;
  }
  if (currentDate != lastDate) {
    lastDate = currentDate;
    midnightRollover();
  }
}

// ── Schedule check every 10 seconds ──────────────────────────
void checkSchedules() {
  int nm = nowMins();
  for (int i = 0; i < 6; i++) {
    if (rooms[i].ovr != -1) continue; // manual override — skip
    bool shouldOn = isInSlot(i);
    if (shouldOn != rooms[i].lightOn) {
      Serial.printf("[%s] Room %d schedule: %s → %s\n",
        getTime().c_str(), i+1,
        rooms[i].lightOn ? "ON" : "OFF",
        shouldOn ? "ON" : "OFF");
      setRelay(i, shouldOn);
      pushStatus(i);
    }
  }
}

// ── Setup ─────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(400);
  Serial.println("\n\n=== Room Controller Booting ===");

  // Init pins as OUTPUT but do NOT set relay state yet
  // We will restore correct state from Firebase after connecting
  for (int i = 0; i < 6; i++) {
    pinMode(RELAY_PINS[i], OUTPUT);
    digitalWrite(RELAY_PINS[i], RELAY_ON);   // NC wiring: de-energise = lights ON during boot
    pinMode(LED_PINS[i], OUTPUT);
    digitalWrite(LED_PINS[i], LED_ON);        // LED ON matches light ON during boot
    snprintf(rooms[i].name, 20, "Room %d", i + 1);
  }
  Serial.println("Pins initialised (NC mode: lights ON during boot)");
  ledStartupTest();

  // Connect WiFi
  if (!connectWiFi()) {
    Serial.println("All WiFi networks failed — rebooting");
    blinkLED(0, 10, 100);
    delay(3000); ESP.restart();
  }

  // Sync time
  configTime(GMT_OFFSET_SEC, DST_OFFSET_SEC, "pool.ntp.org", "time.google.com");
  Serial.print("NTP");
  struct tm t; int n = 0;
  while (!getLocalTime(&t) && n++ < 20) { delay(500); Serial.print("."); }
  Serial.println("\nTime: " + getTime());

  // Read Firebase and restore exact state that was set before power off
  // This includes: manual override, scheduled slots, room names
  Serial.println("Restoring state from Firebase...");
  readAllRooms();

  // Log what was restored
  for (int i = 0; i < 6; i++) {
    Serial.printf("  Room %d: ovr=%d  slots=%d  light=%s  %s\n",
      i+1, rooms[i].ovr, rooms[i].slotCount,
      rooms[i].lightOn ? "ON" : "OFF",
      rooms[i].ovr == 1  ? "(Manual ON — restored)" :
      rooms[i].ovr == 0  ? "(Manual OFF — restored)" :
      rooms[i].lightOn   ? "(Schedule active)" : "(Schedule off)");
  }

  pushAllStatus();
  getLocalTime(&t);
  lastDate = t.tm_mday;
  Serial.println("=== Ready — state restored from Firebase ===");
}

// ── Loop ──────────────────────────────────────────────────────
void loop() {

  // Poll override every 3 seconds
  if (millis() - lastPollTime > POLL_INTERVAL) {
    lastPollTime = millis();
    if (WiFi.status() == WL_CONNECTED) pollOverrides();
  }

  // Check schedule every 10 seconds
  if (millis() - lastScheduleCheck > SCHEDULE_INTERVAL) {
    lastScheduleCheck = millis();
    checkSchedules();
    checkMidnight();  // detect date change → rollover slots
  }

  // Refresh slots only — no relay state change unless slots count changes
  if (millis() - lastSlotRefresh > SLOT_REFRESH) {
    lastSlotRefresh = millis();
    refreshSlotsOnly();
  }

  // Heartbeat every 5 minutes
  if (millis() - lastStatusPush > HEARTBEAT) {
    lastStatusPush = millis();
    pushAllStatus();
    Serial.println("Heartbeat: " + getTime());
  }

  // WiFi watchdog — tries all networks if current drops
  wifiWatchdog();

  delay(10);
}
