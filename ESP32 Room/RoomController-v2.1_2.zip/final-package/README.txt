╔══════════════════════════════════════════════════════╗
║         ROOM CONTROLLER v2.0 — QUICK START          ║
║         Firebase + ESP32 + PWA                      ║
╚══════════════════════════════════════════════════════╝

YOUR FIREBASE CREDENTIALS (already in sketch)
─────────────────────────────────────────────
Database URL : https://roomcontrol-1d14d-default-rtdb.asia-southeast1.firebasedatabase.app
API Key      : AIzaSyAa1DZpoK03WeGkWOdyaCER-sl2KRwjVZA
Project      : roomcontrol-1d14d

FILES IN THIS PACKAGE
─────────────────────
pwa/
  index.html      ← Deploy to GitHub Pages / Netlify
  manifest.json   ← PWA install config (icons fixed)
  sw.js           ← Service worker (offline support)
  icons/
    icon-192.png  ← App icon — lightbulb + WiFi design
    icon-512.png  ← App icon large

esp32/
  RoomController_Firebase.ino  ← Upload to ESP32

docs/
  DOCUMENTATION.md     ← Full guide with all steps
  wiring-diagram.html  ← Open in browser for wiring

3 THINGS TO DO
──────────────
1. EDIT WIFI IN SKETCH
   Open esp32/RoomController_Firebase.ino
   Change these 2 lines only:
     #define WIFI_SSID      "YOUR_WIFI_NAME"
     #define WIFI_PASSWORD  "YOUR_WIFI_PASSWORD"
   Everything else is already configured.

2. UPLOAD TO ESP32 (via ArduinoDroid on Android tablet)
   - Install ArduinoDroid from Play Store
   - Wait for SDK download (5-10 min, needs WiFi)
   - Open .ino file → Select Board: ESP32 Dev Module
   - Connect ESP32 via OTG cable → Upload
   - Serial Monitor (115200) → confirm "=== Ready! ==="

3. DEPLOY PWA + CONFIGURE
   - Upload pwa/ folder contents to GitHub Pages
   - Open URL in Chrome on any device
   - Settings → enter Database URL + API Key → Save
   - Tap "Test Firebase connection" → green dot
   - Chrome → Add to Home Screen to install as app

WIRING SUMMARY
──────────────
Relay module:
  VCC → ESP32 VIN    GND → ESP32 GND
  IN1 → GPIO 26 (Room 1)    IN2 → GPIO 27 (Room 2)
  IN3 → GPIO 14 (Room 3)    IN4 → GPIO 12 (Room 4)
  IN5 → GPIO 13 (Room 5)    IN6 → GPIO 15 (Room 6)

LED indicators (each: GPIO → 330Ω → LED+ → LED- → GND):
  Room 1: GPIO 2     Room 2: GPIO 4     Room 3: GPIO 5
  Room 4: GPIO 18    Room 5: GPIO 19    Room 6: GPIO 21

LED long leg (+) = positive = connects to resistor
LED short leg (-) = negative = connects to GND

PRIORITY LOGIC
──────────────
  Manual Override ON  → relay always ON  (schedule ignored)
  Manual Override OFF → relay always OFF (schedule ignored)
  Auto mode (null)    → schedule controls relay

See docs/DOCUMENTATION.md for full details.

v2.0 — Flicker fixed, overlap detection, LED indicators, PWA icon
