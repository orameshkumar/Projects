/*
 * ============================================================
 *  Room Controller — ESP32 + Firebase Realtime Database
 *  Board  : ESP32 Dev Module
 *  Libraries: WiFi, HTTPClient, WiFiClientSecure, ArduinoJson
 *
 *  Flicker fix:
 *  - Slot refresh does NOT call applyState during active slot
 *  - Slots parsed into temp buffer first, only copied if valid
 *  - Bad HTTP responses always skipped — state never changes
 *  - Schedule check compares seconds not just minutes
 * ============================================================
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <time.h>

// ── YOUR CREDENTIALS ─────────────────────────────────────────
// Add up to 5 WiFi networks — ESP32 tries each in order
// If one fails it automatically tries the next one
// Leave unused entries as empty strings ""
struct WiFiNetwork { const char* ssid; const char* password; };

const WiFiNetwork wifiNetworks[] = {
  { "YOUR_WIFI_NAME_1",  "YOUR_WIFI_PASSWORD_1" },  // ← primary
  { "YOUR_WIFI_NAME_2",  "YOUR_WIFI_PASSWORD_2" },  // ← fallback 1
  { "YOUR_WIFI_NAME_3",  "YOUR_WIFI_PASSWORD_3" },  // ← fallback 2
  { "",                  ""                     },  // unused
  { "",                  ""                     },  // unused
};
const int WIFI_NETWORK_COUNT = 5;
int currentWiFiIdx = 0;  // tracks which network is currently connected

#define FIREBASE_URL   "https://roomcontrol-1d14d-default-rtdb.asia-southeast1.firebasedatabase.app"

// Timezone: IST India = 19800 | GMT = 0 | EST = -18000
#define GMT_OFFSET_SEC  19800
#define DST_OFFSET_SEC  0
// ─────────────────────────────────────────────────────────────

// Relay GPIO pins Room 1 to 6
const int RELAY_PINS[6] = { 26, 27, 14, 12, 13, 15 };

// LED GPIO pins Room 1 to 6
const int LED_PINS[6]   = {  2,  4,  5, 18, 19, 21 };

// ACTIVE LOW = most relay modules (LOW = relay ON)
// If relay turns ON with HIGH swap these:
// ── NC WIRING (Normally Closed) ──────────────────────────────
// Light ON  = relay de-energised = NC contact closed = GPIO HIGH
// Light OFF = relay energised    = NC contact open   = GPIO LOW
// When ESP32 is OFF → relay de-energised → NC closed → lights ON (safe fallback)
#define RELAY_ON  HIGH   // de-energise coil → NC closed → light ON
#define RELAY_OFF LOW    // energise coil    → NC open   → light OFF
#define LED_ON    HIGH
#define LED_OFF   LOW

// ── Room state ────────────────────────────────────────────────
struct Slot { int sh, sm, eh, em; bool recurring; bool activated; bool expired; };

struct Room {
  bool lightOn   = false;
  int  ovr       = -1;   // -1=auto  0=force OFF  1=force ON
  Slot slots[10];
  int  slotCount = 0;
  char name[20];
};

Room rooms[6];

unsigned long lastPollTime      = 0;
unsigned long lastScheduleCheck = 0;
unsigned long lastSlotRefresh   = 0;
unsigned long lastStatusPush    = 0;
int           lastDate          = -1;  // tracks day-of-month for midnight detection

// Intervals
const unsigned long POLL_INTERVAL     = 3000;   // override poll every 3 sec
const unsigned long SCHEDULE_INTERVAL = 10000;  // schedule check every 10 sec
const unsigned long SLOT_REFRESH      = 10000;  // slot refresh every 10 sec — picks up activation fast
const unsigned long HEARTBEAT         = 300000; // heartbeat every 5 min

// ── Time helpers ──────────────────────────────────────────────
int nowH()    { struct tm t; getLocalTime(&t); return t.tm_hour; }
int nowMn()   { struct tm t; getLocalTime(&t); return t.tm_min;  }
int nowSec()  { struct tm t; getLocalTime(&t); return t.tm_sec;  }
int nowMins() { return nowH() * 60 + nowMn(); }

String getTime() {
  struct tm t; getLocalTime(&t);
  char buf[9]; snprintf(buf, 9, "%02d:%02d:%02d", t.tm_hour, t.tm_min, t.tm_sec);
  return String(buf);
}

bool parseTime(String s, int &h, int &m) {
  s.trim();
  int c = s.indexOf(':');
  if (c < 0) return false;
  h = s.substring(0, c).toInt();
  m = s.substring(c + 1).toInt();
  return (h >= 0 && h < 24 && m >= 0 && m < 60);
}

// ── Relay + LED — only fires GPIO if state truly changes ──────
void setRelay(int idx, bool on) {
  // Always write to hardware — don't trust software state matches physical state
  // NC wiring: RELAY_ON=HIGH (de-energised=NC closed=light ON)
  //            RELAY_OFF=LOW (energised=NC open=light OFF)
  digitalWrite(RELAY_PINS[idx], on ? RELAY_ON : RELAY_OFF);
  digitalWrite(LED_PINS[idx],   on ? LED_ON   : LED_OFF);
  if (rooms[idx].lightOn != on) {
    rooms[idx].lightOn = on;
    Serial.printf("[%s] Room %d → %s\n", getTime().c_str(), idx+1, on?"ON":"OFF");
  }
}

// ── mergeSlots — merge overlapping/adjacent slots into clean ranges ──
// Example: [9-11, 10-12] → [9-12]  [9-10, 11-12] → [9-10, 11-12]
// ── mergeSlots — only merge AUTO slots (no code required) ────
// Slots with activation codes are kept SEPARATE — each has its own
// code and activation state. Merging them would destroy that.
// Only auto-approved (no-code) slots get merged when overlapping.
void mergeSlots(int idx) {
  if (rooms[idx].slotCount < 2) return;

  // Sort slots by start time
  for (int i = 0; i < rooms[idx].slotCount - 1; i++) {
    for (int j = i + 1; j < rooms[idx].slotCount; j++) {
      int si = rooms[idx].slots[i].sh * 60 + rooms[idx].slots[i].sm;
      int sj = rooms[idx].slots[j].sh * 60 + rooms[idx].slots[j].sm;
      if (sj < si) {
        Slot tmp = rooms[idx].slots[i];
        rooms[idx].slots[i] = rooms[idx].slots[j];
        rooms[idx].slots[j] = tmp;
      }
    }
  }
  // Note: we intentionally do NOT merge slots with codes
  // Each coded slot is independent with its own activation state
  // isInSlot() checks each slot individually
}

// ── isInSlot — true if current time is in an ACTIVATED slot ──
// Slot must be both: within time range AND activated by user code
// Non-activated slots do NOT turn on the relay
bool isInSlot(int idx) {
  int nm = nowMins();
  for (int i = 0; i < rooms[idx].slotCount; i++) {
    int s = rooms[idx].slots[i].sh * 60 + rooms[idx].slots[i].sm;
    int e = rooms[idx].slots[i].eh * 60 + rooms[idx].slots[i].em;
    if (nm >= s && nm < e) {
      if (rooms[idx].slots[i].activated) return true;
    }
  }
  return false;
}

// ── applyState — uses override first, then schedule ──────────
void applyState(int idx) {
  if      (rooms[idx].ovr == 1)  setRelay(idx, true);
  else if (rooms[idx].ovr == 0)  setRelay(idx, false);
  else                           setRelay(idx, isInSlot(idx));
}

// ── WiFi multi-network connect ────────────────────────────────
// Tries each network in wifiNetworks[] in order
// Returns true if connected, false if all failed
bool connectWiFi() {
  for (int n = 0; n < WIFI_NETWORK_COUNT; n++) {
    // Skip empty entries
    if (strlen(wifiNetworks[n].ssid) == 0) continue;

    Serial.printf("Trying WiFi %d: %s\n", n + 1, wifiNetworks[n].ssid);
    WiFi.disconnect(true);
    delay(300);
    WiFi.begin(wifiNetworks[n].ssid, wifiNetworks[n].password);

    int tries = 0;
    while (WiFi.status() != WL_CONNECTED && tries++ < 20) {
      delay(500);
      Serial.print(".");
      // Blink LED for the current network index
      digitalWrite(LED_PINS[n % 6], tries % 2 == 0 ? LED_ON : LED_OFF);
    }
    // Restore LED to match current relay state after blink
    digitalWrite(LED_PINS[n % 6], rooms[n % 6].lightOn ? LED_ON : LED_OFF);

    if (WiFi.status() == WL_CONNECTED) {
      currentWiFiIdx = n;
      Serial.printf("\nConnected to: %s  IP: %s\n",
        wifiNetworks[n].ssid, WiFi.localIP().toString().c_str());
      return true;
    }
    Serial.printf("\nFailed: %s\n", wifiNetworks[n].ssid);
  }
  return false;  // all networks failed
}

// ── WiFi watchdog — tries all networks if current drops ───────
void wifiWatchdog() {
  if (WiFi.status() == WL_CONNECTED) return;

  Serial.println("WiFi lost — trying all networks");
  // Flash all LEDs to signal WiFi lost
  for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_ON);
  delay(300);
  for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_OFF);
  delay(200);
  for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_ON);
  delay(300);
  for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_OFF);

  if (connectWiFi()) {
    Serial.println("WiFi restored");
    // Restore LEDs to correct room states after reconnect
    for (int i = 0; i < 6; i++) {
      digitalWrite(LED_PINS[i], rooms[i].lightOn ? LED_ON : LED_OFF);
    }
  } else {
    Serial.println("All WiFi failed — rebooting in 10s");
    delay(10000);
    ESP.restart();
  }
}

// ── LED startup test — quick blink then settle to relay state ──
void ledStartupTest() {
  // Quick 3 blinks on all LEDs
  for (int b = 0; b < 3; b++) {
    for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_ON);
    delay(150);
    for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_OFF);
    delay(100);
  }
  // End with LEDs OFF — matches relay state (all OFF at boot)
  // LEDs will be set correctly by applyState() after Firebase read
  for (int i = 0; i < 6; i++) digitalWrite(LED_PINS[i], LED_OFF);
}

void blinkLED(int idx, int times, int ms) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_PINS[idx], LED_ON);  delay(ms);
    digitalWrite(LED_PINS[idx], LED_OFF); delay(ms);
  }
  // Restore LED to match current light state after blink
  digitalWrite(LED_PINS[idx], rooms[idx].lightOn ? LED_ON : LED_OFF);
}

// ── HTTP helpers — returns "error" on failure ─────────────────
String fbGet(String path) {
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.begin(client, FIREBASE_URL + path + ".json");
  http.setTimeout(5000);
  int code = http.GET();
  String result = "error";
  if (code == 200) {
    result = http.getString();
    result.trim();
  } else {
    Serial.printf("fbGet failed %s code=%d\n", path.c_str(), code);
  }
  http.end();
  return result;
}

bool fbPut(String path, String jsonValue) {
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.begin(client, FIREBASE_URL + path + ".json");
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(5000);
  int code = http.PUT(jsonValue);
  http.end();
  return (code == 200);
}

// ── Push status back to Firebase ─────────────────────────────
void pushStatus(int idx) {
  String base = "/rooms/room" + String(idx + 1);
  fbPut(base + "/lightOn",  rooms[idx].lightOn ? "true" : "false");
  fbPut(base + "/lastSeen", "\"" + getTime() + "\"");
}

void pushAllStatus() {
  for (int i = 0; i < 6; i++) { pushStatus(i); delay(150); }
}

// ── Parse slots — into TEMP buffer, only copy if fully valid ──
void parseSlots(int idx, String json) {
  if (json == "null" || json == "" || json == "error" || json.length() < 5) {
    rooms[idx].slotCount = 0;
    return;
  }

  Slot tempSlots[10];
  int  tempCount = 0;
  int  pos = 0;

  while (pos < (int)json.length() && tempCount < 10) {
    int si = json.indexOf("\"s\":\"", pos);
    int ei = json.indexOf("\"e\":\"", pos);
    if (si < 0 || ei < 0) break;
    String startStr = json.substring(si + 5, si + 10);
    String endStr   = json.substring(ei + 5, ei + 10);
    int sh, sm, eh, em;
    if (parseTime(startStr, sh, sm) && parseTime(endStr, eh, em)) {
      int objStart = json.lastIndexOf('{', si);
      int objEnd   = json.indexOf('}', ei);
      bool isRecurring = false;
      bool isActivated = false;
      if (objStart >= 0 && objEnd >= 0) {
        String slotObj = json.substring(objStart, objEnd + 1);
        // Recurring flag
        isRecurring = slotObj.indexOf("\"recurring\":true") >= 0;
        // Activated: activatedAt exists and is NOT null
        bool hasActivatedField = slotObj.indexOf("\"activatedAt\":") >= 0;
        bool activatedIsNull   = slotObj.indexOf("\"activatedAt\":null") >= 0;
        isActivated = (hasActivatedField && !activatedIsNull);
        // Auto slot: code is explicitly null = no code required = always activated
        // Missing code field OR code is a string = requires activation
        bool codeIsNull = slotObj.indexOf("\"code\":null") >= 0;
        if (codeIsNull) isActivated = true;
      }
      tempSlots[tempCount++] = {sh, sm, eh, em, isRecurring, isActivated, false};
    }
    pos = max(si, ei) + 10;
  }

  if (tempCount > 0 || json == "[]") {
    rooms[idx].slotCount = tempCount;
    for (int i = 0; i < tempCount; i++) rooms[idx].slots[i] = tempSlots[i];
    mergeSlots(idx);
    for (int i = 0; i < rooms[idx].slotCount; i++) {
    }
  } else {
  }
}

// ── Read all rooms from Firebase on boot ─────────────────────
void readAllRooms() {
  String json = fbGet("/rooms");
  if (json == "" || json == "null" || json == "error") {
    return;
  }

  for (int i = 0; i < 6; i++) {
    String key = "\"room" + String(i + 1) + "\":{";
    int start = json.indexOf(key);
    if (start < 0) continue;
    String roomJson = json.substring(start);

    // ── Override — strict parsing, never reset on bad value ──
    int ovIdx = roomJson.indexOf("\"override\":");
    if (ovIdx >= 0) {
      String ovVal = roomJson.substring(ovIdx + 11, ovIdx + 16);
      ovVal.trim();
      if      (ovVal.startsWith("true"))  rooms[i].ovr = 1;
      else if (ovVal.startsWith("false")) rooms[i].ovr = 0;
      else if (ovVal.startsWith("null") || ovVal.startsWith("-1"))
                                          rooms[i].ovr = -1;
      // else: unknown/malformed — KEEP existing ovr, do not reset
    }
    // If override field missing entirely — keep existing ovr too
    // (do NOT reset to -1 just because field is absent)

    // Name
    int nameIdx = roomJson.indexOf("\"name\":\"");
    if (nameIdx >= 0) {
      int ns = nameIdx + 8;
      int ne = roomJson.indexOf("\"", ns);
      strncpy(rooms[i].name, roomJson.substring(ns, ne).c_str(), 20);
    }

    // Slots — Firebase stores as nested object {"slots":{"0":{...},"1":{...}}}
    // Try array format first, then object format
    int slotIdx = roomJson.indexOf("\"slots\":[");
    if (slotIdx >= 0) {
      int as = slotIdx + 8;
      int ae = roomJson.indexOf("]", as) + 1;
      parseSlots(i, roomJson.substring(as, ae));
    } else {
      // Firebase nested format — fetch directly for this room
      String slotJson = fbGet("/rooms/room" + String(i + 1) + "/slots");
      if (slotJson != "error" && slotJson != "null" && slotJson.length() > 2) {
        parseSlots(i, slotJson);
      } else {
        rooms[i].slotCount = 0;
      }
    }

    applyState(i);
  }
}

// ── Refresh slots only — does NOT touch relay state ──────────
// KEY FIX: separate from applyState so slot update never causes flicker
void refreshSlotsOnly() {
  for (int i = 0; i < 6; i++) {
    String slotJson = fbGet("/rooms/room" + String(i+1) + "/slots");
    if (slotJson != "error") {
      // Save previous state for comparison
      int  prevCount = rooms[i].slotCount;
      bool prevActivated[10] = {};
      for (int j = 0; j < rooms[i].slotCount && j < 10; j++)
        prevActivated[j] = rooms[i].slots[j].activated;

      parseSlots(i, slotJson);

      // Re-apply if slot count changed OR any activation flag changed
      bool activationChanged = false;
      if (rooms[i].slotCount != prevCount) {
        activationChanged = true;
      } else {
        for (int j = 0; j < rooms[i].slotCount; j++) {
          if (rooms[i].slots[j].activated != prevActivated[j]) {
            activationChanged = true;
            break;
          }
        }
      }

      if (activationChanged) {
        applyState(i);
      }
    }
    delay(150);
  }
}

// ── Poll overrides every 3 seconds ───────────────────────────
void pollOverrides() {
  for (int i = 0; i < 6; i++) {
    String val = fbGet("/rooms/room" + String(i + 1) + "/override");

    // Skip bad reads — NEVER change state on error
    if (val == "error" || val == "") { delay(100); continue; }

    int newOvr;
    if      (val == "true"  || val == "1")  newOvr = 1;
    else if (val == "false" || val == "0")  newOvr = 0;
    else if (val == "null"  || val == "-1") newOvr = -1;
    else {
      // Unknown value — skip, never change active override
      delay(100); continue;
    }

    // Extra guard: if manual override is active and new value is auto (-1)
    // only accept if Firebase returned full "null" string — not a short bad read
    if (rooms[i].ovr != -1 && newOvr == -1 && val.length() < 4) {
      delay(100); continue;
    }

    if (newOvr != rooms[i].ovr) {
      Serial.printf("Room %d override: %d → %d\n", i+1, rooms[i].ovr, newOvr);
      rooms[i].ovr = newOvr;
      applyState(i);
      pushStatus(i);
    }
    delay(100);
  }
}

// ── Midnight rollover — runs once when date changes ───────────
// Rule:
//   Recurring slots → today only, stay forever, never in tomorrow
//   One-time today  → deleted at midnight
//   One-time tomorrow → moves to today, tomorrow cleared after
void midnightRollover() {
  Serial.println("=== Midnight rollover ===");

  for (int i = 0; i < 6; i++) {
    String base = "/rooms/room" + String(i + 1);

    // Read tomorrow's one-time slots from Firebase
    String tomorrowJson = fbGet(base + "/slotsT");

    // ── Build new TODAY ───────────────────────────────────────
    // Keep today's recurring slots + add tomorrow's one-time slots
    String newTodayJson = "[";
    bool first = true;

    // Always keep recurring slots (they live here forever)
    for (int j = 0; j < rooms[i].slotCount; j++) {
      if (!rooms[i].slots[j].recurring) continue;
      if (!first) newTodayJson += ",";
      char s[6], e[6];
      snprintf(s, 6, "%02d:%02d", rooms[i].slots[j].sh, rooms[i].slots[j].sm);
      snprintf(e, 6, "%02d:%02d", rooms[i].slots[j].eh, rooms[i].slots[j].em);
      // Read existing slot to preserve code field
      String slotPath = base + "/slots/" + String(j);
      String existingSlot = fbGet(slotPath);
      String codeField = "";
      if (existingSlot != "error" && existingSlot != "null") {
        int codeIdx = existingSlot.indexOf("\"code\":\"");
        if (codeIdx >= 0) {
          int codeEnd = existingSlot.indexOf("\"", codeIdx + 8);
          if (codeEnd >= 0) {
            codeField = ",\"code\":\"" + existingSlot.substring(codeIdx + 8, codeEnd) + "\"";
          }
        }
      }
      // Reset activatedAt for new day — user must re-activate
      newTodayJson += "{\"s\":\"" + String(s) + "\",\"e\":\"" + String(e) + "\",\"recurring\":true" + codeField + ",\"activatedAt\":null}";
      first = false;
    }

    // Move tomorrow's one-time slots into today
    // (skip any recurring ones — recurring should only be in today)
    if (tomorrowJson != "null" && tomorrowJson != "" &&
        tomorrowJson != "error" && tomorrowJson.length() > 2) {
      int pos = 0;
      while (pos < (int)tomorrowJson.length()) {
        int si = tomorrowJson.indexOf("\"s\":\"", pos);
        int ei = tomorrowJson.indexOf("\"e\":\"", pos);
        if (si < 0 || ei < 0) break;
        int objStart = tomorrowJson.lastIndexOf('{', si);
        int objEnd   = tomorrowJson.indexOf('}', ei);
        if (objStart >= 0 && objEnd >= 0) {
          String obj = tomorrowJson.substring(objStart, objEnd + 1);
          // Only move one-time slots (skip recurring)
          if (obj.indexOf("\"recurring\":true") < 0) {
            String startStr = tomorrowJson.substring(si + 5, si + 10);
            String endStr   = tomorrowJson.substring(ei + 5, ei + 10);
            if (!first) newTodayJson += ",";
            // Preserve the full slot object (code, date, etc) — just omit activatedAt
            // Extract code if present
            String codeField2 = "";
            int codeIdx2 = obj.indexOf("\"code\":\"");
            if (codeIdx2 >= 0) {
              int codeEnd2 = obj.indexOf("\"", codeIdx2 + 8);
              if (codeEnd2 >= 0) {
                codeField2 = ",\"code\":\"" + obj.substring(codeIdx2 + 8, codeEnd2) + "\"";
              }
            }
            newTodayJson += "{\"s\":\"" + startStr + "\",\"e\":\"" + endStr + "\"" + codeField2 + ",\"activatedAt\":null}";
            first = false;
          }
        }
        pos = max(si, ei) + 10;
      }
    }
    newTodayJson += "]";

    // Tomorrow is always cleared — user adds fresh one-time slots as needed
    // Recurring slots are never placed in tomorrow
    fbPut(base + "/slots",  newTodayJson);
    fbPut(base + "/slotsT", "[]");
    delay(200);
  }

  readAllRooms();
  Serial.println("=== Rollover complete ===");
}

// ── Check if date changed — called every minute ───────────────
void checkMidnight() {
  struct tm t; getLocalTime(&t);
  int currentDate = t.tm_mday;
  if (lastDate == -1) {
    lastDate = currentDate;  // first run — just record date
    return;
  }
  if (currentDate != lastDate) {
    lastDate = currentDate;
    midnightRollover();
  }
}

// ── Mark slot as expired in Firebase ─────────────────────────
void markSlotExpired(int roomIdx, int slotIdx) {
  String path = "/rooms/room" + String(roomIdx + 1) + "/slots";
  String slotsJson = fbGet(path);
  if (slotsJson == "error" || slotsJson == "null" || slotsJson.length() < 5) return;

  // Find and update the matching slot — add expired:true
  // Simple approach: find the slot by time and inject expired field
  char startBuf[6], endBuf[6];
  snprintf(startBuf, 6, "%02d:%02d", rooms[roomIdx].slots[slotIdx].sh, rooms[roomIdx].slots[slotIdx].sm);
  snprintf(endBuf,   6, "%02d:%02d", rooms[roomIdx].slots[slotIdx].eh, rooms[roomIdx].slots[slotIdx].em);

  String searchKey = String("\"s\":\"") + startBuf + "\"";
  int pos = slotsJson.indexOf(searchKey);
  if (pos < 0) return;

  // Find the slot object boundaries
  int objStart = slotsJson.lastIndexOf('{', pos);
  int objEnd   = slotsJson.indexOf('}', pos);
  if (objStart < 0 || objEnd < 0) return;

  String slotObj = slotsJson.substring(objStart, objEnd + 1);
  // Only mark expired if not already activated
  if (slotObj.indexOf("\"activatedAt\":null") >= 0 ||
      slotObj.indexOf("\"activatedAt\":") < 0) {
    // Add expired:true to the slot object
    String newSlotObj = slotObj.substring(0, slotObj.length() - 1);
    newSlotObj += ",\"expired\":true}";
    String newSlotsJson = slotsJson.substring(0, objStart) +
                         newSlotObj +
                         slotsJson.substring(objEnd + 1);
    fbPut(path, newSlotsJson);
    Serial.printf("Room %d slot %s-%s marked expired\n",
      roomIdx+1, startBuf, endBuf);
  }
}

// ── Schedule check every 10 seconds ──────────────────────────
void checkSchedules() {
  int nm = nowMins();
  for (int i = 0; i < 6; i++) {
    if (rooms[i].ovr != -1) continue; // manual override — skip

    // Check each slot individually for expiry detection
    for (int j = 0; j < rooms[i].slotCount; j++) {
      int slotStart = rooms[i].slots[j].sh * 60 + rooms[i].slots[j].sm;
      int slotEnd   = rooms[i].slots[j].eh * 60 + rooms[i].slots[j].em;
      bool hasCode  = true; // assume code required (safe default)

      // Slot just ended — check if it was never activated
      // nm is just past slotEnd (within 10 seconds of end)
      if (nm >= slotEnd && nm <= slotEnd + 1) {
        if (!rooms[i].slots[j].activated && hasCode) {
          // Slot ended without activation — mark expired
          markSlotExpired(i, j);
        }
      }
    }

    bool shouldOn = isInSlot(i);
    if (shouldOn != rooms[i].lightOn) {
      Serial.printf("[%s] Room %d schedule: %s → %s\n",
        getTime().c_str(), i+1,
        rooms[i].lightOn ? "ON" : "OFF",
        shouldOn ? "ON" : "OFF");
      setRelay(i, shouldOn);
      pushStatus(i);
    }
  }
}

// ── Setup ─────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(400);
  Serial.println("\n\n=== Room Controller Booting ===");

  // Init pins as OUTPUT but do NOT set relay state yet
  // We will restore correct state from Firebase after connecting
  for (int i = 0; i < 6; i++) {
    pinMode(RELAY_PINS[i], OUTPUT);
    digitalWrite(RELAY_PINS[i], RELAY_OFF);  // Start OFF — correct state restored from Firebase after boot
    pinMode(LED_PINS[i], OUTPUT);
    digitalWrite(LED_PINS[i], LED_OFF);
    snprintf(rooms[i].name, 20, "Room %d", i + 1);
  }
  ledStartupTest();

  // Connect WiFi
  if (!connectWiFi()) {
    Serial.println("All WiFi networks failed — rebooting");
    blinkLED(0, 10, 100);
    delay(3000); ESP.restart();
  }

  // Sync time
  configTime(GMT_OFFSET_SEC, DST_OFFSET_SEC, "pool.ntp.org", "time.google.com");
  Serial.print("NTP");
  struct tm t; int n = 0;
  while (!getLocalTime(&t) && n++ < 20) { delay(500); Serial.print("."); }
  Serial.println("\nTime: " + getTime());

  // Read Firebase and restore exact state that was set before power off
  // This includes: manual override, scheduled slots, room names
  readAllRooms();

  // Log what was restored
  for (int i = 0; i < 6; i++) {
  }

  pushAllStatus();
  getLocalTime(&t);
  lastDate = t.tm_mday;
  Serial.println("=== Ready — state restored from Firebase ===");
}

// ── Loop ──────────────────────────────────────────────────────
void loop() {

  // Poll override every 3 seconds
  if (millis() - lastPollTime > POLL_INTERVAL) {
    lastPollTime = millis();
    if (WiFi.status() == WL_CONNECTED) pollOverrides();
  }

  // Check schedule every 10 seconds
  if (millis() - lastScheduleCheck > SCHEDULE_INTERVAL) {
    lastScheduleCheck = millis();
    checkSchedules();
    checkMidnight();  // detect date change → rollover slots
  }

  // Refresh slots only — no relay state change unless slots count changes
  if (millis() - lastSlotRefresh > SLOT_REFRESH) {
    lastSlotRefresh = millis();
    refreshSlotsOnly();
  }

  // Heartbeat every 5 minutes
  if (millis() - lastStatusPush > HEARTBEAT) {
    lastStatusPush = millis();
    pushAllStatus();
  }

  // WiFi watchdog — tries all networks if current drops
  wifiWatchdog();

  delay(10);
}
